<?php $__env->startSection('title', 'Contact'); ?>
<?php $__env->startSection('meta', 'Get in touch with the Helpquora team — start your free trial, book a demo or ask us anything about moving your customer service to one calm workspace.'); ?>

<?php $__env->startSection('content'); ?>


<section class="page-hero">
  <div class="container">
    <div data-reveal>
      <div class="crumb"><a href="<?php echo e(route('home')); ?>">Home</a> · Contact</div>
      <span class="eyebrow center-eb">Let's talk</span>
      <h1 class="h-xl">We'd genuinely <span class="mark">love to hear</span> from you.</h1>
      <p class="lead">Starting a trial, booking a demo or just weighing things up — tell us a
        little about your team and a real person will reply within one business day.</p>
    </div>
  </div>
</section>


<section class="section-tight">
  <div class="container">
    <div class="contact-grid">

      
      <div class="cinfo" data-reveal>
        <div class="cinfo-item">
          <span class="ci-ic">@</span>
          <div>
            <div class="ci-k">Email us</div>
            <div class="ci-v"><a href="mailto:support@helpquora.com">support@helpquora.com</a></div>
            <p class="muted" style="font-size:.88rem;margin:4px 0 0">For support, sales and everything in between.</p>
          </div>
        </div>
        <div class="cinfo-item">
          <span class="ci-ic">☏</span>
          <div>
            <div class="ci-k">Call us</div>
            <div class="ci-v">+1 (415) 555-0142</div>
            <p class="muted" style="font-size:.88rem;margin:4px 0 0">Monday to Friday, 7am – 7pm PT.</p>
          </div>
        </div>
        <div class="cinfo-item">
          <span class="ci-ic">⌂</span>
          <div>
            <div class="ci-k">Visit us</div>
            <div class="ci-v">2300 Market Street, Suite 400</div>
            <p class="muted" style="font-size:.88rem;margin:4px 0 0">San Francisco, CA 94114, United States</p>
          </div>
        </div>
        <div class="cinfo-item">
          <span class="ci-ic">✦</span>
          <div>
            <div class="ci-k">Early access</div>
            <div class="ci-v">Onboarding now</div>
            <p class="muted" style="font-size:.88rem;margin:4px 0 0">We're welcoming the next wave of support teams this quarter.</p>
          </div>
        </div>
      </div>

      
      <div class="form-card" id="form" data-reveal data-delay="1">
        <?php if(session('sent')): ?>
          <div class="flash">
            Thanks, <?php echo e(session('sent')); ?> — your message is on its way. A member of our team
            will reply to you within one business day.
          </div>
        <?php endif; ?>

        <h2 class="h-sm" style="margin-bottom:6px">Send us a message</h2>
        <p class="muted" style="font-size:.95rem;margin-bottom:24px">Fields marked with an asterisk are required.</p>

        <form method="POST" action="<?php echo e(route('contact.submit')); ?>#form">
          <?php echo csrf_field(); ?>
          <div class="field-row">
            <div class="field">
              <label for="name">Full name *</label>
              <input type="text" id="name" name="name" value="<?php echo e(old('name')); ?>" placeholder="Jordan Avery" required>
              <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="err"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="field">
              <label for="email">Work email *</label>
              <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="you@company.com" required>
              <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="err"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="field-row">
            <div class="field">
              <label for="company">Company</label>
              <input type="text" id="company" name="company" value="<?php echo e(old('company')); ?>" placeholder="Your company">
              <?php $__errorArgs = ['company'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="err"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="field">
              <label for="team">Support team size</label>
              <select id="team" name="team">
                <?php $sizes = ['Just me','2 – 5 agents','6 – 20 agents','21 – 50 agents','50+ agents']; ?>
                <option value="">Select an option</option>
                <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($s); ?>" <?php if(old('team')==$s): echo 'selected'; endif; ?>><?php echo e($s); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
          </div>
          <div class="field">
            <label for="message">How can we help? *</label>
            <textarea id="message" name="message" placeholder="Tell us a little about your team and what you're hoping to improve…" required><?php echo e(old('message')); ?></textarea>
            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="err"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <button type="submit" class="btn btn-pink btn-lg" style="width:100%">Send message</button>
          <p class="muted center" style="font-size:.84rem;margin-top:14px">
            By sending this you agree to our <a href="<?php echo e(route('privacy')); ?>" style="color:var(--primary)">Privacy Policy</a>.
          </p>
        </form>
      </div>

    </div>
  </div>
</section>


<section class="section">
  <div class="container">
    <div class="sec-head center-head" data-reveal>
      <span class="eyebrow center-eb">Before you write</span>
      <h2 class="h-lg">A few quick answers</h2>
    </div>
    <div class="faq" data-reveal>
      <?php
        $cfaqs = [
          ['How soon will I hear back?', 'Every message is answered by a real person within one business day — usually much sooner. Urgent? Mention it in your note and we will prioritise your reply.'],
          ['Can I see Helpquora before committing?', 'Of course. Ask for a demo in your message and we will walk you through the platform live, using examples close to your own type of business.'],
          ['Do you help us move from our old tool?', 'Yes. Guided migration is free on every plan — our onboarding team handles the import of conversations, contacts and help articles for you.'],
          ['Is the free trial really free?', 'It is. You get 14 days with every feature unlocked and no credit card required. We will only ask for billing details if you decide to continue.'],
        ];
      ?>
      <?php $__currentLoopData = $cfaqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="faq-item">
          <button class="faq-q"><?php echo e($f[0]); ?> <span class="pm">+</span></button>
          <div class="faq-a"><p><?php echo e($f[1]); ?></p></div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/laralink/www/helpgeniepro/resources/views/pages/contact.blade.php ENDPATH**/ ?>