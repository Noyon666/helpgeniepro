<?php
  $nav = [
    ['Platform', 'platform'],
    ['Solutions', 'solutions'],
    ['Pricing', 'pricing'],
    ['Integrations', 'integrations'],
    ['Resources', 'resources'],
    ['Company', 'about'],
  ];
?>
<header class="site-header">
  <div class="container-wide">
    <nav class="nav">
      <a href="<?php echo e(route('home')); ?>" class="brand" aria-label="Helpquora home">
        <img src="<?php echo e(asset('images/dark-logo.png')); ?>" alt="Helpquora" class="brand-logo">
      </a>

      <div class="nav-links">
        <?php $__currentLoopData = $nav; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="<?php echo e(route($item[1])); ?>" class="<?php echo e(request()->routeIs($item[1]) ? 'active' : ''); ?>"><?php echo e($item[0]); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

      <div class="nav-cta">
        <a href="<?php echo e(route('contact')); ?>" class="btn btn-ghost btn-demo">Book a demo</a>
        <a href="<?php echo e(route('contact')); ?>" class="btn btn-pink">Start free</a>
        <button class="burger" aria-label="Open menu">
          <span></span><span></span><span></span>
        </button>
      </div>
    </nav>
  </div>
</header>
<?php /**PATH /home/laralink/www/helpgeniepro/resources/views/partials/header.blade.php ENDPATH**/ ?>