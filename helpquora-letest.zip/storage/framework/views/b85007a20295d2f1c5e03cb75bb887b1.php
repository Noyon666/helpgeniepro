<!DOCTYPE html>
<html lang="en" class="no-js">
<head>
  <script>document.documentElement.className='js';</script>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo $__env->yieldContent('title', 'Customer service that works like magic'); ?> — Helpquora</title>
  <meta name="description" content="<?php echo $__env->yieldContent('meta', 'Helpquora unifies every support conversation, automates the busywork and gives your team superpowers — so customers get answers in seconds.'); ?>">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer">
  <link rel="stylesheet" href="<?php echo e(asset('css/site.css')); ?>">
  <link rel="icon" type="image/png" href="<?php echo e(asset('images/fav-icon.png')); ?>">
  <link rel="apple-touch-icon" href="<?php echo e(asset('images/fav-icon.png')); ?>">
</head>
<body>

  <div class="topbar">
    Helpquora is in early access — onboarding the next wave of support teams now.
    <span class="dot">●</span>
    <a href="<?php echo e(route('contact')); ?>">Claim your spot →</a>
  </div>

  <?php echo $__env->make('partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <?php echo $__env->make('partials.mobile-nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <main>
    <?php echo $__env->yieldContent('content'); ?>
  </main>

  <?php echo $__env->renderWhen(!isset($hideCta), 'partials.cta', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1])); ?>
  <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <script src="<?php echo e(asset('js/site.js')); ?>" defer></script>
</body>
</html>
<?php /**PATH /home/laralink/www/helpquora/resources/views/layouts/app.blade.php ENDPATH**/ ?>