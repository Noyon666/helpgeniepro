<?php
  $mnav = [
    ['Platform', 'platform'], ['Solutions', 'solutions'], ['Pricing', 'pricing'],
    ['Integrations', 'integrations'], ['Resources', 'resources'], ['Company', 'about'],
    ['Contact', 'contact'],
  ];
?>
<div class="mobile-nav">
  <div class="mn-head">
    <a href="<?php echo e(route('home')); ?>" class="brand" aria-label="Helpquora home">
      <img src="<?php echo e(asset('images/dark-logo.png')); ?>" alt="Helpquora" class="brand-logo">
    </a>
    <button class="mn-close" aria-label="Close menu">&times;</button>
  </div>
  <?php $__currentLoopData = $mnav; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(route($item[1])); ?>" class="mn-link"><?php echo e($item[0]); ?></a>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <a href="<?php echo e(route('contact')); ?>" class="btn btn-pink btn-lg btn-arrow">Start free</a>
</div>
<?php /**PATH /home/laralink/www/helpgeniepro/resources/views/partials/mobile-nav.blade.php ENDPATH**/ ?>